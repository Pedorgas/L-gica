var firebaseConfig = {
  apiKey: "AIzaSyAGeN0gXpPo07zW7pq-TUeMBwBe5ZjqaUw",
  authDomain: "lista-de-tarefas-14371.firebaseapp.com",
  databaseURL: "https://lista-de-tarefas-14371.firebaseio.com",
  projectId: "lista-de-tarefas-14371",
  storageBucket: "lista-de-tarefas-14371.appspot.com",
  messagingSenderId: "266439584608",
  appId: "1:266439584608:web:932e0dd2def8caa52d4c05"
}
// Initialize Firebase
firebase.initializeApp(firebaseConfig)

const db = firebase.firestore()
  
let tasks = []

function createDelButton(task){
    const newButton = document.createElement("button")
    newButton.appendChild(document.createTextNode('Excluir'))
    newButton.setAttribute('onClick', `deleteTask("${task.id}")`)
    return newButton
}

function renderTasks() {
    const taskList = document.getElementById("taskList")
    taskList.innerHTML = ''
    for(task of tasks){
        const newItem = document.createElement("li")
        newItem.appendChild(document.createTextNode(task.title))
        newItem.appendChild(createDelButton(task))
        taskList.appendChild(newItem)
    }
}

async function readTasks() {
    tasks = []
    const logTasks = await db.collection("tasks").get()
    for (doc of logTasks.docs) {
        tasks.push({
            id: doc.id,
            title: doc.data().title,
        })
    }
    renderTasks()
}

async function addTask(){
    const newTask = document.getElementById("newTask").value
    const date = new Date().toISOString()
    await db.collection("tasks").add({
        title: newTask,
        date: date,
    })
    readTasks()
}

async function deleteTask(id){
    await db.collection("tasks").doc(id).delete()
    readTasks()
}

readTasks()
